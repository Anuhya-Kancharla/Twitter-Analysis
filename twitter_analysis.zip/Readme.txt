1.Run twitter.py and it generates a file "your-searchstring".txt
2.Run challenge.py
3.Give the created text file location
4.It will generate files : MaxTweets, MaxRetweets , MaxFollowers in the same folder



github link :https://github.com/Anuhya-Kancharla/Twitter-Analysis